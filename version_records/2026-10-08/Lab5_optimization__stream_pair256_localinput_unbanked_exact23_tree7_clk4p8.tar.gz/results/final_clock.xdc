create_clock -period 5.44 [get_ports clk_i]
