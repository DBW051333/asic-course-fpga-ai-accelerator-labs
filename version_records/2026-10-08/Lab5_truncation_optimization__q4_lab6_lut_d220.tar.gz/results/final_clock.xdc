create_clock -period 5.3 [get_ports clk_i]
