create_clock -period 4.51 [get_ports clk_i]
