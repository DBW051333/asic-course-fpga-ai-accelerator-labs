create_clock -period 5.33 [get_ports clk_i]
