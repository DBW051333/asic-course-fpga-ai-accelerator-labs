create_clock -period 4.8 [get_ports clk_i]
