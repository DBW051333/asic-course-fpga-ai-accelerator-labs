create_clock -period 4.9 [get_ports clk_i]
