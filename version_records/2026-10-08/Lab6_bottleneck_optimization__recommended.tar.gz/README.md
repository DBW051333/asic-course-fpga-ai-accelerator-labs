# 推荐工程

选中方案：postroute_fanout。

已布线结果：4.74 ns，169 拍，801.06 ns。

结果来自保存的 DCP：[final_routed.dcp](/home/ding/vivado_project/Lab6_bottleneck_optimization/postroute_fanout/results/final_routed.dcp)。

源码重新布局布线不保证复现同一周期。请参见[试验记录](/home/ding/vivado_project/Lab6_bottleneck_optimization/Lab6第一层瓶颈优化对比.md)和选中方案的实现脚本。
