`timescale 1ps/1ps
module baseline(input wire clk_slow,clk_fast,rst,
 input wire [6:0] addr_i,
 input wire [127:0] input_a_i,input_b_i,
 output reg [1023:0] result_o);
 (* rom_style="block" *) reg [399:0] weights_a[0:127],weights_b[0:127];
 initial begin
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank0.mem",weights_a);
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank1.mem",weights_b);
 end
 reg [399:0] wa,wb; reg [127:0] xa,xb;
 always @(posedge clk_slow)begin
 wa<=weights_a[addr_i]; wb<=weights_b[addr_i];xa<=input_a_i;xb<=input_b_i;
 end
 genvar g;generate for(g=0;g<16;g=g+1)begin:lane
 reg signed [24:0] aa,ab;reg signed [7:0] ba,bb;
 (* use_dsp="yes" *) reg signed [32:0] ma,mb;
 reg signed [32:0] pa,pb;
 wire signed [15:0] ha=$signed(pa[32:16])+pa[15];
 wire signed [15:0] hb=$signed(pb[32:16])+pb[15];
 always @(posedge clk_slow)begin
 aa<=wa[399-g*25 -:25];ab<=wb[399-g*25 -:25];
 ba<=xa[127-g*8 -:8];bb<=xb[127-g*8 -:8];
 ma<=aa*ba;mb<=ab*bb;pa<=ma;pb<=mb;
 result_o[511-g*32 -:32]<={ha,pa[15:0]};
 result_o[1023-g*32 -:32]<={hb,pb[15:0]};
 end
 end endgenerate
 endmodule
