`timescale 1ps/1ps
module mp_probe(input wire clk_slow,clk_fast,rst,
 input wire [6:0] addr_i,
 input wire [127:0] input_a_i,input_b_i,
 output reg [1023:0] result_o);
 (* rom_style="block" *) reg [399:0] weights_a[0:127],weights_b[0:127];
 initial begin
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank0.mem",weights_a);
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank1.mem",weights_b);
 end
 reg [399:0] wa,wb; reg [127:0] xa,xb;
 always @(posedge clk_slow)begin
 wa<=weights_a[addr_i]; wb<=weights_b[addr_i];xa<=input_a_i;xb<=input_b_i;
 end
 // Related 2:1 clocks; synchronous reset fixes the fast slot phase.
 reg phase=0;reg [2:0] slot_pipe=0;
 always @(posedge clk_fast)begin
 if(rst)begin phase<=0;slot_pipe<=0;end
 else begin phase<=~phase;slot_pipe<={slot_pipe[1:0],phase};end
 end
 reg [511:0] half_a,half_b;
 reg [1023:0] pair_hold;
 // Pair buffers are coherent at this edge, after the second slot write.
 always @(negedge clk_slow) pair_hold<={half_b,half_a};
 always @(posedge clk_slow) result_o<=pair_hold;
 genvar g; generate for(g=0;g<16;g=g+1)begin:lane
 reg signed [24:0] w_b_hold;
 reg signed [7:0] x_b_hold;
 reg signed [24:0] a_r;reg signed [7:0] b_r;
 (* use_dsp="yes" *) reg signed [32:0] m_r;
 reg signed [32:0] p_r;
 wire signed [15:0] hi=$signed(p_r[32:16])+p_r[15];
 always @(posedge clk_fast)begin
 if(!phase)begin
 a_r<=wa[399-g*25 -:25];b_r<=xa[127-g*8 -:8];
 w_b_hold<=wb[399-g*25 -:25];x_b_hold<=xb[127-g*8 -:8];
 end else begin a_r<=w_b_hold;b_r<=x_b_hold;end
 m_r<=a_r*b_r;p_r<=m_r;
 if(slot_pipe[2])half_b[511-g*32 -:32]<={hi,p_r[15:0]};
 else half_a[511-g*32 -:32]<={hi,p_r[15:0]};
 end
 end endgenerate
 endmodule
