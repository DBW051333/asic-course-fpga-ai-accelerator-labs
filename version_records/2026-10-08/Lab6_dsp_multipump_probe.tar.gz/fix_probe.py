from pathlib import Path
R=Path('/home/ding/vivado_project/Lab6_dsp_multipump_probe');R2=R/'registered'
s=(R/'rtl/mp_probe.v').read_text().replace('reg [399:0] wa,wb; reg [127:0] xa,xb;', 'reg [399:0] wa,wb,wa_read,wb_read; reg [127:0] xa,xb,xa_read,xb_read;').replace('wa<=weights_a[addr_i]; wb<=weights_b[addr_i];xa<=input_a_i;xb<=input_b_i;', 'wa_read<=weights_a[addr_i];wb_read<=weights_b[addr_i];xa_read<=input_a_i;xb_read<=input_b_i;\n wa<=wa_read;wb<=wb_read;xa<=xa_read;xb<=xb_read;')
a=s.index(' reg signed [24:0] a_r;');b=s.index(' end endgenerate',a)
s=s[:a]+''' wire signed [24:0] a_sel=phase?w_b_hold:$signed(wa[399-g*25 -:25]);
 wire signed [7:0] b_sel=phase?x_b_hold:$signed(xa[127-g*8 -:8]);
 wire [47:0] dsp_p;wire signed [32:0] p_r=dsp_p[32:0];
 wire signed [15:0] hi=$signed(p_r[32:16])+p_r[15];
 DSP48E1 #(.AREG(1),.BREG(1),.ACASCREG(1),.BCASCREG(1),.MREG(1),.PREG(1),
 .ADREG(0),.DREG(0),.CREG(0),.INMODEREG(0),.OPMODEREG(0),.ALUMODEREG(0),
 .CARRYINREG(0),.CARRYINSELREG(0),.USE_MULT("MULTIPLY"),.USE_SIMD("ONE48")) dsp(
 .CLK(clk_fast),.A({{5{a_sel[24]}},a_sel}),.B({{10{b_sel[7]}},b_sel}),.C(48'd0),.D(25'd0),
 .ACIN(30'd0),.BCIN(18'd0),.PCIN(48'd0),.OPMODE(7'b0000101),.ALUMODE(4'd0),.INMODE(5'd0),
 .CARRYIN(1'b0),.CARRYINSEL(3'd0),.CARRYCASCIN(1'b0),.MULTSIGNIN(1'b0),
 .CEA1(1'b1),.CEA2(1'b1),.CEB1(1'b1),.CEB2(1'b1),.CEM(1'b1),.CEP(1'b1),
 .CEAD(1'b1),.CED(1'b1),.CEC(1'b1),.CEINMODE(1'b1),.CECTRL(1'b1),.CEALUMODE(1'b1),.CECARRYIN(1'b1),
 .RSTA(1'b0),.RSTB(1'b0),.RSTM(1'b0),.RSTP(1'b0),.RSTC(1'b0),.RSTD(1'b0),
 .RSTINMODE(1'b0),.RSTCTRL(1'b0),.RSTALUMODE(1'b0),.RSTALLCARRYIN(1'b0),.P(dsp_p));
 always @(posedge clk_fast)begin
 if(!phase)begin w_b_hold<=wb[399-g*25 -:25];x_b_hold<=xb[127-g*8 -:8];end
 if(slot_pipe[2])half_b[511-g*32 -:32]<={hi,p_r[15:0]};
 else half_a[511-g*32 -:32]<={hi,p_r[15:0]};
 end
'''+s[b:]
(R2/'rtl/mp_probe.v').write_text(s)
(R2/'rtl/mp_clocked.v').write_text('''`timescale 1ps/1ps
module mp_clocked(input clk_i,rst,input [6:0]addr_i,input [127:0] input_a_i,input_b_i,output [1023:0]result_o);
 wire fast_raw,slow_raw,fb_raw,fb,clk_fast,clk_slow,locked;
 MMCME2_BASE #(.CLKIN1_PERIOD(4.36),.CLKFBOUT_MULT_F(4.0),.DIVCLK_DIVIDE(1),
 .CLKOUT0_DIVIDE_F(2.0),.CLKOUT1_DIVIDE(4),.STARTUP_WAIT("FALSE")) mmcm(
 .CLKIN1(clk_i),.CLKFBIN(fb),.RST(rst),.PWRDWN(1'b0),.CLKFBOUT(fb_raw),
 .CLKOUT0(fast_raw),.CLKOUT1(slow_raw),.LOCKED(locked));
 BUFG feedback(.I(fb_raw),.O(fb));BUFG fastbuf(.I(fast_raw),.O(clk_fast));BUFG slowbuf(.I(slow_raw),.O(clk_slow));
 mp_probe core(.clk_fast(clk_fast),.clk_slow(clk_slow),.rst(rst|~locked),.addr_i(addr_i),.input_a_i(input_a_i),.input_b_i(input_b_i),.result_o(result_o));
 endmodule
''')
(R2/'timing.xdc').write_text('''create_clock -name reference -period 4.360 [get_ports clk_i]
set_input_delay -clock [get_clocks -of_objects [get_pins slowbuf/O]] 0 [get_ports {addr_i[*] input_a_i[*] input_b_i[*]}]
set_input_delay -clock reference 0 [get_ports rst]
set_output_delay -clock [get_clocks -of_objects [get_pins slowbuf/O]] 0 [get_ports {result_o[*]}]
''')
tcl=(R/'run.tcl').read_text().replace(str(R),str(R2)).replace('add_files '+str(R2)+'/rtl/mp_probe.v','add_files [glob '+str(R2)+'/rtl/*.v]').replace('synth_design -top mp_probe','synth_design -top mp_clocked');(R2/'run.tcl').write_text(tcl)
tb=(R/'sim/tb.sv').read_text().replace('frame>=4 && frame<2052','frame>=5 && frame<2053').replace('expected[frame-4]','expected[frame-5]');(R2/'sim/tb.sv').write_text(tb)
