`timescale 1ps/1ps
module tb;
 reg clk_fast=0,clk_slow=0,rst=1;
 always #1090 clk_fast=~clk_fast;
 // Slow positive edges coincide with even fast positive edges.
 initial begin #1090;clk_slow=1; forever #2180 clk_slow=~clk_slow;end
 reg [6:0] addr_i=0;reg [127:0] input_a_i=0,input_b_i=0;
 wire [1023:0] result_o;
 mp_probe dut(.*);
 reg [1023:0] expected[0:2055];
 reg [399:0] ra[0:127],rb[0:127];
 reg [2047:0] course_inputs[0:1];
 reg signed [24:0] w;reg signed [7:0] x,w0,w1;
 reg signed [15:0] p0,p1;
 integer frame=0,g,errors=0,checks=0,k,mode;
 initial begin
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank0.mem",ra);
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank1.mem",rb);
 $readmemh("/home/ding/vivado_project/Lab5_optimization/data/stream_pair256_hybrid_inputs.mem",course_inputs);
 repeat(6)@(negedge clk_slow);#1;rst=0;
 for(k=0;k<2048;k=k+1)begin
 addr_i=k%128;
 for(g=0;g<16;g=g+1)begin
 case(k/256)
 0:begin input_a_i[127-g*8 -:8]=course_inputs[k%2][2047-g*8 -:8];input_b_i[127-g*8 -:8]=course_inputs[k%2][2047-(g+16)*8 -:8];end
 1:begin input_a_i[127-g*8 -:8]=8'h80;input_b_i[127-g*8 -:8]=8'h7f;end
 2:begin input_a_i[127-g*8 -:8]=8'hff;input_b_i[127-g*8 -:8]=0;end
 default:begin input_a_i[127-g*8 -:8]=$random;input_b_i[127-g*8 -:8]=$random;end
 endcase
 end
 @(negedge clk_slow);
 end
 repeat(6)@(negedge clk_slow);
 $display("SUMMARY frames=%0d individual_products=%0d errors=%0d",checks,checks*64,errors);
 if(errors!=0)$fatal(1,"FAIL");
 $display("PASS: related-clock ROM-fed paired multiplications and slow-domain reassembly");$finish;
 end
 always @(posedge clk_slow)begin
 if(!rst)begin
 expected[frame]=0;
 for(g=0;g<16;g=g+1)begin
 w=ra[addr_i][399-g*25 -:25];x=input_a_i[127-g*8 -:8];w0=w[7:0];w1=(w>>>16)+(w0<0);p0=w0*x;p1=w1*x;
 expected[frame][511-g*32 -:32]={p1,p0};
 w=rb[addr_i][399-g*25 -:25];x=input_b_i[127-g*8 -:8];w0=w[7:0];w1=(w>>>16)+(w0<0);p0=w0*x;p1=w1*x;
 expected[frame][1023-g*32 -:32]={p1,p0};
 end
 #1;
 if(frame>=4 && frame<2052)begin
 checks=checks+1;
 if(result_o!==expected[frame-4])begin errors=errors+1;if(errors<5)$display("MISMATCH frame=%0d got=%h expected=%h",frame,result_o,expected[frame-4]);end
 end
 frame=frame+1;
 end
 end
endmodule
