from pathlib import Path
R=Path('/home/ding/vivado_project/Lab6_dsp_multipump_probe')
rtl='''module mp_probe(input wire clk_slow,clk_fast,rst,
 input wire [6:0] addr_i,
 input wire [127:0] input_a_i,input_b_i,
 output reg [1023:0] result_o);
 (* rom_style="block" *) reg [399:0] weights_a[0:127],weights_b[0:127];
 initial begin
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank0.mem",weights_a);
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank1.mem",weights_b);
 end
 reg [399:0] wa,wb; reg [127:0] xa,xb;
 always @(posedge clk_slow)begin
 wa<=weights_a[addr_i]; wb<=weights_b[addr_i];xa<=input_a_i;xb<=input_b_i;
 end
 // Related 2:1 clocks; synchronous reset fixes the fast slot phase.
 reg phase=0;reg [2:0] slot_pipe=0;
 always @(posedge clk_fast)begin
 if(rst)begin phase<=0;slot_pipe<=0;end
 else begin phase<=~phase;slot_pipe<={slot_pipe[1:0],phase};end
 end
 reg [511:0] half_a,half_b;
 reg [1023:0] pair_hold;
 // Pair buffers are coherent at this edge, after the second slot write.
 always @(negedge clk_slow) pair_hold<={half_b,half_a};
 always @(posedge clk_slow) result_o<=pair_hold;
 genvar g; generate for(g=0;g<16;g=g+1)begin:lane
 reg signed [24:0] w_b_hold;
 reg signed [7:0] x_b_hold;
 reg signed [24:0] a_r;reg signed [7:0] b_r;
 (* use_dsp="yes" *) reg signed [32:0] m_r;
 reg signed [32:0] p_r;
 wire signed [15:0] hi=$signed(p_r[32:16])+p_r[15];
 always @(posedge clk_fast)begin
 if(!phase)begin
 a_r<=wa[399-g*25 -:25];b_r<=xa[127-g*8 -:8];
 w_b_hold<=wb[399-g*25 -:25];x_b_hold<=xb[127-g*8 -:8];
 end else begin a_r<=w_b_hold;b_r<=x_b_hold;end
 m_r<=a_r*b_r;p_r<=m_r;
 if(slot_pipe[2])half_b[511-g*32 -:32]<={hi,p_r[15:0]};
 else half_a[511-g*32 -:32]<={hi,p_r[15:0]};
 end
 end endgenerate
 endmodule
'''
(R/'rtl/mp_probe.v').write_text(rtl)
tb='''`timescale 1ps/1ps
module tb;
 reg clk_fast=0,clk_slow=0,rst=1;
 always #1090 clk_fast=~clk_fast;
 // Slow positive edges coincide with even fast positive edges.
 initial begin #1090;clk_slow=1; forever #2180 clk_slow=~clk_slow;end
 reg [6:0] addr_i=0;reg [127:0] input_a_i=0,input_b_i=0;
 wire [1023:0] result_o;
 mp_probe dut(.*);
 reg [1023:0] expected[0:2055];
 reg [399:0] ra[0:127],rb[0:127];
 reg [2047:0] course_inputs[0:1];
 reg signed [24:0] w;reg signed [7:0] x,w0,w1;
 reg signed [15:0] p0,p1;
 integer frame=0,g,errors=0,checks=0,k,mode;
 initial begin
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank0.mem",ra);
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank1.mem",rb);
 $readmemh("/home/ding/vivado_project/Lab5_optimization/data/stream_pair256_hybrid_inputs.mem",course_inputs);
 repeat(6)@(negedge clk_slow);rst=0;
 for(k=0;k<2048;k=k+1)begin
 addr_i=k%128;
 for(g=0;g<16;g=g+1)begin
 case(k/256)
 0:begin input_a_i[127-g*8 -:8]=course_inputs[k%2][2047-g*8 -:8];input_b_i[127-g*8 -:8]=course_inputs[k%2][2047-(g+16)*8 -:8];end
 1:begin input_a_i[127-g*8 -:8]=8'h80;input_b_i[127-g*8 -:8]=8'h7f;end
 2:begin input_a_i[127-g*8 -:8]=8'hff;input_b_i[127-g*8 -:8]=0;end
 default:begin input_a_i[127-g*8 -:8]=$random;input_b_i[127-g*8 -:8]=$random;end
 endcase
 end
 @(negedge clk_slow);
 end
 repeat(6)@(negedge clk_slow);
 $display("SUMMARY frames=%0d individual_products=%0d errors=%0d",checks,checks*64,errors);
 if(errors!=0)$fatal(1,"FAIL");
 $display("PASS: related-clock ROM-fed paired multiplications and slow-domain reassembly");$finish;
 end
 always @(posedge clk_slow)begin
 if(!rst)begin
 expected[frame]=0;
 for(g=0;g<16;g=g+1)begin
 w=ra[addr_i][399-g*25 -:25];x=input_a_i[127-g*8 -:8];w0=w[7:0];w1=(w>>>16)+(w0<0);p0=w0*x;p1=w1*x;
 expected[frame][511-g*32 -:32]={p1,p0};
 w=rb[addr_i][399-g*25 -:25];x=input_b_i[127-g*8 -:8];w0=w[7:0];w1=(w>>>16)+(w0<0);p0=w0*x;p1=w1*x;
 expected[frame][1023-g*32 -:32]={p1,p0};
 end
 #1;
 if(frame>=4 && frame<2052)begin
 checks=checks+1;
 if(result_o!==expected[frame-4])begin errors=errors+1;if(errors<5)$display("MISMATCH frame=%0d got=%h expected=%h",frame,result_o,expected[frame-4]);end
 end
 frame=frame+1;
 end
 end
endmodule
'''
(R/'sim/tb.sv').write_text(tb)
(R/'timing.xdc').write_text('''create_clock -name fast -period 2.180 [get_ports clk_fast]
create_generated_clock -name slow -source [get_ports clk_fast] -divide_by 2 [get_ports clk_slow]
set_input_delay -clock slow 0 [get_ports {addr_i[*] input_a_i[*] input_b_i[*]}]
set_input_delay -clock fast 0 [get_ports rst]
set_output_delay -clock slow 0 [get_ports {result_o[*]}]
''')
tcl=f'''set_param general.maxThreads 8
create_project mp_probe {R}/vivado -part xc7z020clg400-1 -force
add_files {R}/rtl/mp_probe.v
read_xdc {R}/timing.xdc
synth_design -top mp_probe -part xc7z020clg400-1 -no_iobuf
write_checkpoint -force {R}/results/synth.dcp
report_utilization -file {R}/results/utilization_synth.rpt
opt_design
place_design -directive Explore
phys_opt_design -directive Explore
route_design -directive Explore
report_utilization -file {R}/results/utilization_impl.rpt
report_timing_summary -report_unconstrained -file {R}/results/timing.rpt
report_timing -from [all_registers] -to [all_registers] -max_paths 12 -file {R}/results/internal_paths.rpt
report_route_status -file {R}/results/route.rpt
report_clock_interaction -file {R}/results/clock_interaction.rpt
report_drc -file {R}/results/drc.rpt
write_checkpoint -force {R}/results/routed.dcp
set fh [open {R}/results/dsp_registers.txt w]
foreach c [get_cells -hier -filter {{REF_NAME == DSP48E1}}] {{puts $fh "$c AREG=[get_property AREG $c] BREG=[get_property BREG $c] MREG=[get_property MREG $c] PREG=[get_property PREG $c]"}}
close $fh
exit
'''
(R/'run.tcl').write_text(tcl)
print(R)
