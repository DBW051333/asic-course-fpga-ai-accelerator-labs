set_param general.maxThreads 8
create_project baseline /home/ding/vivado_project/Lab6_dsp_multipump_probe/vivado -part xc7z020clg400-1 -force
add_files /home/ding/vivado_project/Lab6_dsp_multipump_probe/rtl/baseline.v
read_xdc /home/ding/vivado_project/Lab6_dsp_multipump_probe/timing.xdc
synth_design -top baseline -part xc7z020clg400-1 -no_iobuf
write_checkpoint -force /home/ding/vivado_project/Lab6_dsp_multipump_probe/baseline_results/synth.dcp
report_utilization -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/baseline_results/utilization_synth.rpt
opt_design
place_design -directive Explore
phys_opt_design -directive Explore
route_design -directive Explore
report_utilization -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/baseline_results/utilization_impl.rpt
report_timing_summary -report_unconstrained -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/baseline_results/timing.rpt
report_timing -from [all_registers] -to [all_registers] -max_paths 12 -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/baseline_results/internal_paths.rpt
report_route_status -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/baseline_results/route.rpt
report_clock_interaction -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/baseline_results/clock_interaction.rpt
report_drc -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/baseline_results/drc.rpt
write_checkpoint -force /home/ding/vivado_project/Lab6_dsp_multipump_probe/baseline_results/routed.dcp
set fh [open /home/ding/vivado_project/Lab6_dsp_multipump_probe/baseline_results/dsp_registers.txt w]
foreach c [get_cells -hier -filter {REF_NAME == DSP48E1}] {puts $fh "$c AREG=[get_property AREG $c] BREG=[get_property BREG $c] MREG=[get_property MREG $c] PREG=[get_property PREG $c]"}
close $fh
exit
