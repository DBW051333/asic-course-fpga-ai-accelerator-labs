set_param general.maxThreads 8
create_project mp_probe /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/vivado -part xc7z020clg400-1 -force
add_files [glob /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/rtl/*.v]
read_xdc /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/timing.xdc
synth_design -top mp_clocked -part xc7z020clg400-1 -no_iobuf
write_checkpoint -force /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/results/synth.dcp
report_utilization -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/results/utilization_synth.rpt
opt_design
place_design -directive Explore
phys_opt_design -directive Explore
route_design -directive Explore
report_utilization -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/results/utilization_impl.rpt
report_timing_summary -report_unconstrained -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/results/timing.rpt
report_timing -from [all_registers] -to [all_registers] -max_paths 12 -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/results/internal_paths.rpt
report_route_status -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/results/route.rpt
report_clock_interaction -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/results/clock_interaction.rpt
report_drc -file /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/results/drc.rpt
write_checkpoint -force /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/results/routed.dcp
set fh [open /home/ding/vivado_project/Lab6_dsp_multipump_probe/registered/results/dsp_registers.txt w]
foreach c [get_cells -hier -filter {REF_NAME == DSP48E1}] {puts $fh "$c AREG=[get_property AREG $c] BREG=[get_property BREG $c] MREG=[get_property MREG $c] PREG=[get_property PREG $c]"}
close $fh
exit
