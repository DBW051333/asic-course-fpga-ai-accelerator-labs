create_clock -name reference -period 4.360 [get_ports clk_i]
set_input_delay -clock [get_clocks -of_objects [get_pins slowbuf/O]] 0 [get_ports {addr_i[*] input_a_i[*] input_b_i[*]}]
set_input_delay -clock reference 0 [get_ports rst]
set_output_delay -clock [get_clocks -of_objects [get_pins slowbuf/O]] 0 [get_ports {result_o[*]}]
