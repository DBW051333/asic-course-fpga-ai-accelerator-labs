`timescale 1ps/1ps
module mp_clocked(input clk_i,rst,input [6:0]addr_i,input [127:0] input_a_i,input_b_i,output [1023:0]result_o);
 wire clk_ref;IBUF clock_input(.I(clk_i),.O(clk_ref));
 wire fast_raw,slow_raw,fb_raw,fb,clk_fast,clk_slow,locked;
 MMCME2_BASE #(.CLKIN1_PERIOD(4.36),.CLKFBOUT_MULT_F(4.0),.DIVCLK_DIVIDE(1),
 .CLKOUT0_DIVIDE_F(2.0),.CLKOUT1_DIVIDE(4),.STARTUP_WAIT("FALSE")) mmcm(
 .CLKIN1(clk_ref),.CLKFBIN(fb),.RST(rst),.PWRDWN(1'b0),.CLKFBOUT(fb_raw),
 .CLKOUT0(fast_raw),.CLKOUT1(slow_raw),.LOCKED(locked));
 BUFG feedback(.I(fb_raw),.O(fb));BUFG fastbuf(.I(fast_raw),.O(clk_fast));BUFG slowbuf(.I(slow_raw),.O(clk_slow));
 mp_probe core(.clk_fast(clk_fast),.clk_slow(clk_slow),.rst(rst|~locked),.addr_i(addr_i),.input_a_i(input_a_i),.input_b_i(input_b_i),.result_o(result_o));
 endmodule
