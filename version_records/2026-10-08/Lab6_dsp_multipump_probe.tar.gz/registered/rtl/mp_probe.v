`timescale 1ps/1ps
module mp_probe(input wire clk_slow,clk_fast,rst,
 input wire [6:0] addr_i,
 input wire [127:0] input_a_i,input_b_i,
 output reg [1023:0] result_o);
 (* rom_style="block" *) reg [399:0] weights_a[0:127],weights_b[0:127];
 initial begin
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank0.mem",weights_a);
 $readmemh("/home/ding/vivado_project/Lab6_limit_search/recommended/data/fc1_bank1.mem",weights_b);
 end
 reg [399:0] wa,wb,wa_read,wb_read; reg [127:0] xa,xb,xa_read,xb_read;
 always @(posedge clk_slow)begin
 wa_read<=weights_a[addr_i];wb_read<=weights_b[addr_i];xa_read<=input_a_i;xb_read<=input_b_i;
 wa<=wa_read;wb<=wb_read;xa<=xa_read;xb<=xb_read;
 end
 // Related 2:1 clocks; synchronous reset fixes the fast slot phase.
 reg phase=0;reg [2:0] slot_pipe=0;
 always @(posedge clk_fast)begin
 if(rst)begin phase<=0;slot_pipe<=0;end
 else begin phase<=~phase;slot_pipe<={slot_pipe[1:0],phase};end
 end
 reg [511:0] half_a,half_b;
 reg [1023:0] pair_hold;
 // Pair buffers are coherent at this edge, after the second slot write.
 always @(negedge clk_slow) pair_hold<={half_b,half_a};
 always @(posedge clk_slow) result_o<=pair_hold;
 genvar g; generate for(g=0;g<16;g=g+1)begin:lane
 reg signed [24:0] w_b_hold;
 reg signed [7:0] x_b_hold;
 wire signed [24:0] a_sel=phase?w_b_hold:$signed(wa[399-g*25 -:25]);
 wire signed [7:0] b_sel=phase?x_b_hold:$signed(xa[127-g*8 -:8]);
 wire [47:0] dsp_p;wire signed [32:0] p_r=dsp_p[32:0];
 wire signed [15:0] hi=$signed(p_r[32:16])+p_r[15];
 DSP48E1 #(.AREG(1),.BREG(1),.ACASCREG(1),.BCASCREG(1),.MREG(1),.PREG(1),
 .ADREG(0),.DREG(0),.CREG(0),.INMODEREG(0),.OPMODEREG(0),.ALUMODEREG(0),
 .CARRYINREG(0),.CARRYINSELREG(0),.USE_MULT("MULTIPLY"),.USE_SIMD("ONE48")) dsp(
 .CLK(clk_fast),.A({{5{a_sel[24]}},a_sel}),.B({{10{b_sel[7]}},b_sel}),.C(48'd0),.D(25'd0),
 .ACIN(30'd0),.BCIN(18'd0),.PCIN(48'd0),.OPMODE(7'b0000101),.ALUMODE(4'd0),.INMODE(5'd0),
 .CARRYIN(1'b0),.CARRYINSEL(3'd0),.CARRYCASCIN(1'b0),.MULTSIGNIN(1'b0),
 .CEA1(1'b1),.CEA2(1'b1),.CEB1(1'b1),.CEB2(1'b1),.CEM(1'b1),.CEP(1'b1),
 .CEAD(1'b1),.CED(1'b1),.CEC(1'b1),.CEINMODE(1'b1),.CECTRL(1'b1),.CEALUMODE(1'b1),.CECARRYIN(1'b1),
 .RSTA(1'b0),.RSTB(1'b0),.RSTM(1'b0),.RSTP(1'b0),.RSTC(1'b0),.RSTD(1'b0),
 .RSTINMODE(1'b0),.RSTCTRL(1'b0),.RSTALUMODE(1'b0),.RSTALLCARRYIN(1'b0),.P(dsp_p));
 always @(posedge clk_fast)begin
 if(!phase)begin w_b_hold<=wb[399-g*25 -:25];x_b_hold<=xb[127-g*8 -:8];end
 if(slot_pipe[2])half_b[511-g*32 -:32]<={hi,p_r[15:0]};
 else half_a[511-g*32 -:32]<={hi,p_r[15:0]};
 end
 end endgenerate
 endmodule
