create_clock -period 4.17 [get_ports clk_i]
