create_clock -period 4.87 [get_ports clk_i]
