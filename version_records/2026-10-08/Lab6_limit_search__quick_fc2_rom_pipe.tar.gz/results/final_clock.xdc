create_clock -period 4.3 [get_ports clk_i]
