create_clock -period 4.74 [get_ports clk_i]
