create_clock -period 5.18 [get_ports clk_i]
