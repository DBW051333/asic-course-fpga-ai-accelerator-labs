create_clock -period 5.000 [get_ports clk_i]
