create_clock -name clk_i -period 5.200 [get_ports clk_i]
