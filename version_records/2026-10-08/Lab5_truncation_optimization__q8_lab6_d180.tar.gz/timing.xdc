create_clock -period 4.800 [get_ports clk_i]
