create_clock -period 4.69 [get_ports clk_i]
