create_clock -period 4.88 [get_ports clk_i]
