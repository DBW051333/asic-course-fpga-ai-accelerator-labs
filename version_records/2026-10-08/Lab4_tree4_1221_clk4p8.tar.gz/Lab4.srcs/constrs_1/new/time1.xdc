create_clock -name clk_i -period 4.800 [get_ports clk_i]
