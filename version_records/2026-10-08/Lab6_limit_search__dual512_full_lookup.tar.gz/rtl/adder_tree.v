module adder_tree(input wire clk,rst_n,input wire [8191:0] data,output wire [31:0] sum_out);
wire signed [15:0] p[0:511];genvar i;generate for(i=0;i<512;i=i+1)begin assign p[i]=data[8191-i*16 -:16];end endgenerate
reg signed [16:0] s0[0:255];integer j0;
always @(posedge clk)for(j0=0;j0<256;j0=j0+1)s0[j0]<=$signed({p[2*j0][15],p[2*j0]})+$signed({p[2*j0+1][15],p[2*j0+1]});
reg signed [17:0] s1[0:127];integer j1;
always @(posedge clk)for(j1=0;j1<128;j1=j1+1)s1[j1]<=$signed({s0[2*j1][16],s0[2*j1]})+$signed({s0[2*j1+1][16],s0[2*j1+1]});
reg signed [18:0] s2[0:63];integer j2;
always @(posedge clk)for(j2=0;j2<64;j2=j2+1)s2[j2]<=$signed({s1[2*j2][17],s1[2*j2]})+$signed({s1[2*j2+1][17],s1[2*j2+1]});
reg signed [19:0] s3[0:31];integer j3;
always @(posedge clk)for(j3=0;j3<32;j3=j3+1)s3[j3]<=$signed({s2[2*j3][18],s2[2*j3]})+$signed({s2[2*j3+1][18],s2[2*j3+1]});
reg signed [20:0] s4[0:15];integer j4;
always @(posedge clk)for(j4=0;j4<16;j4=j4+1)s4[j4]<=$signed({s3[2*j4][19],s3[2*j4]})+$signed({s3[2*j4+1][19],s3[2*j4+1]});
reg signed [21:0] s5[0:7];integer j5;
always @(posedge clk)for(j5=0;j5<8;j5=j5+1)s5[j5]<=$signed({s4[2*j5][20],s4[2*j5]})+$signed({s4[2*j5+1][20],s4[2*j5+1]});
reg signed [22:0] s6[0:3];integer j6;
always @(posedge clk)for(j6=0;j6<4;j6=j6+1)s6[j6]<=$signed({s5[2*j6][21],s5[2*j6]})+$signed({s5[2*j6+1][21],s5[2*j6+1]});
reg signed [23:0] s7[0:1];integer j7;
always @(posedge clk)for(j7=0;j7<2;j7=j7+1)s7[j7]<=$signed({s6[2*j7][22],s6[2*j7]})+$signed({s6[2*j7+1][22],s6[2*j7+1]});
reg signed [24:0] s8[0:0];integer j8;
always @(posedge clk)for(j8=0;j8<1;j8=j8+1)s8[j8]<=$signed({s7[2*j8][23],s7[2*j8]})+$signed({s7[2*j8+1][23],s7[2*j8+1]});
assign sum_out={{7{s8[0][24]}},s8[0]};endmodule
