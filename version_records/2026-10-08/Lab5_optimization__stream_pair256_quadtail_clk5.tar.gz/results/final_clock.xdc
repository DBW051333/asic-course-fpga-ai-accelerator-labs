create_clock -period 5.5 [get_ports clk_i]
