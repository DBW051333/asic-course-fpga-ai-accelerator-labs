create_clock -period 5.04 [get_ports clk_i]
