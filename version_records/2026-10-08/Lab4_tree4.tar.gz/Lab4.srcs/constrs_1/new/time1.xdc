create_clock -name clk_i -period 10.000 [get_ports clk_i]
