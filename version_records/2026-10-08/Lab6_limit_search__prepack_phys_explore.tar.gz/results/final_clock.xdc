create_clock -period 4.48 [get_ports clk_i]
