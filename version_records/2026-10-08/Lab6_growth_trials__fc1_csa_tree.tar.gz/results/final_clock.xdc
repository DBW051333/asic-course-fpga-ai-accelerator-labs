create_clock -period 4.19 [get_ports clk_i]
