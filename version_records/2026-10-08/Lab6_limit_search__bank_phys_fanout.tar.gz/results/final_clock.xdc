create_clock -period 4.36 [get_ports clk_i]
