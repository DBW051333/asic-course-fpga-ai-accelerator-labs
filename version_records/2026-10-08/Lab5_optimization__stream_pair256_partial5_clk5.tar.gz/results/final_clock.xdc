create_clock -period 5.42 [get_ports clk_i]
