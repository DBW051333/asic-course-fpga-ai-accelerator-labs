create_clock -period 6.14 [get_ports clk_i]
