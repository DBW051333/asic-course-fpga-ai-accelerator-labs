create_clock -period 6.67 [get_ports clk_i]
