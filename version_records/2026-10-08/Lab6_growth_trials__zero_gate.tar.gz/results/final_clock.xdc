create_clock -period 4.1 [get_ports clk_i]
