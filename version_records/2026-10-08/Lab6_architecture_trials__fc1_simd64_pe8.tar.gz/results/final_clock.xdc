create_clock -period 4.79 [get_ports clk_i]
