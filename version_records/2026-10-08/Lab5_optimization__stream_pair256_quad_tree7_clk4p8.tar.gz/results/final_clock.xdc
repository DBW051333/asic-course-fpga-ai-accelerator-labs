create_clock -period 5.35 [get_ports clk_i]
