create_clock -period 6.68 [get_ports clk_i]
