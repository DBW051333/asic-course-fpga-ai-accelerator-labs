create_clock -period 5.22 [get_ports clk_i]
