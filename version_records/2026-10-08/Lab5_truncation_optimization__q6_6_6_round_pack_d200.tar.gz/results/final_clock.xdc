create_clock -period 6.94 [get_ports clk_i]
