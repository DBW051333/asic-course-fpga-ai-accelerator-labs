create_clock -period 7.65 [get_ports clk_i]
