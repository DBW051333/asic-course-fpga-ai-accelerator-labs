create_clock -period 5.08 [get_ports clk_i]
