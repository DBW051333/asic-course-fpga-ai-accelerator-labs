create_clock -period 4.78 [get_ports clk_i]
